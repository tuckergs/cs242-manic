# manic
2D fighting game written in libgdx.

Visit the wiki's ![Getting Started](https://github.com/Lorenzsj/manic/wiki) page if you are unsure about how to integrate our project in eclipse.

#Development Progress
Visit the wiki's ![Goals and Assignments](https://github.com/Lorenzsj/manic/wiki/Goals-and-Assignments) page to see the current status of development.

# Understanding the Structure
After learning to use Box2D, the structure of our has changed a bit. Below is an image of my explanation to Gabe. ![Mike of the lengedary Block Bunny](https://www.youtube.com/watch?v=85A1w1iD2oA) does an excellent job of explaning it. But if you would like, I can sit down and explain it line for line. Let me know.

![](http://i.imgur.com/SPgHB0R.png)

# Using the Demo
Press **space** in the demo application to make Shaq jump, **A** and **D** to make him dribble side to side.
![](http://i.imgur.com/B2WU5pF.png)


