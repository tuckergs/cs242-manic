var dir_0dbae601bdf0b6fb0ed9384ef6f4a7fe =
[
    [ "BuildConfig.java", "_build_config_8java.html", [
      [ "BuildConfig", "classcom_1_1manic_1_1game_1_1android_1_1_build_config.html", null ]
    ] ],
    [ "R.java", "_r_8java.html", [
      [ "R", "classcom_1_1manic_1_1game_1_1android_1_1_r.html", null ]
    ] ]
];