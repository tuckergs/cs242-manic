var namespacecom_1_1manic_1_1game_1_1android =
[
    [ "AndroidLauncher", "classcom_1_1manic_1_1game_1_1android_1_1_android_launcher.html", "classcom_1_1manic_1_1game_1_1android_1_1_android_launcher" ],
    [ "BuildConfig", "classcom_1_1manic_1_1game_1_1android_1_1_build_config.html", null ],
    [ "R", "classcom_1_1manic_1_1game_1_1android_1_1_r.html", null ]
];