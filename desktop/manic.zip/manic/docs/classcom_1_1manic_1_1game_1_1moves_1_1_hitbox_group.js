var classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group =
[
    [ "HitboxGroup", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html#ad39846042180ce5d0d45b871cb68ed64", null ],
    [ "add", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html#addfdf2f858cfb637cfee7f180577e5a6", null ],
    [ "get", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html#a83525a89968b176c996dd837df2af983", null ],
    [ "removeAllHitboxes", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html#aa44223dafc9108482eee11b3e04272ec", null ],
    [ "removeHitbox", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html#ab279416f94a47a40b718454712eddda6", null ],
    [ "hitboxes", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html#af45938a6570c74f93e3c241a82fc2403", null ]
];