var namespacecom_1_1manic_1_1game_1_1exceptions =
[
    [ "InvalidXMLException", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception" ]
];