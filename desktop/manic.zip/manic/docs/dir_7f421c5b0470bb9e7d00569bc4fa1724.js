var dir_7f421c5b0470bb9e7d00569bc4fa1724 =
[
    [ "IOSLauncher.java", "_i_o_s_launcher_8java.html", [
      [ "IOSLauncher", "classcom_1_1manic_1_1game_1_1_i_o_s_launcher.html", "classcom_1_1manic_1_1game_1_1_i_o_s_launcher" ]
    ] ]
];