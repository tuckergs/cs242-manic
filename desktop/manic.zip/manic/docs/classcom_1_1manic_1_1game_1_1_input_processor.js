var classcom_1_1manic_1_1game_1_1_input_processor =
[
    [ "keyDown", "classcom_1_1manic_1_1game_1_1_input_processor.html#ae6dc6114bde23e666ad9bcd1848c78e1", null ],
    [ "keyUp", "classcom_1_1manic_1_1game_1_1_input_processor.html#a679c82f5abafaafdbc3b9de2ad84d053", null ]
];