var classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception =
[
    [ "InvalidXMLException", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#ac5bbedbda05895d71cb72b6c4c485035", null ],
    [ "getMessage", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#ac75dc66416854c5b58d53014e5effa83", null ],
    [ "setCantParseFile", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#a4a11a23f8fd80b0511e2da61058a690a", null ],
    [ "setCantParseXML", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#a34c8fbf657b6aee4eb3e7685f95d90e1", null ],
    [ "setInvalidTag", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#acfdd906252724c2ecbbac72b815b9d2f", null ],
    [ "setMissingTag", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#ade582352c11308d7d5ea5e8cff74e4ef", null ],
    [ "err_no", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#afef67a54ec165e748c257ab3f43618c0", null ]
];