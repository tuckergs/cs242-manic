var classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager =
[
    [ "get", "classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager.html#ad4606d96efe58102ee9f1f554972c58c", null ],
    [ "load", "classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager.html#a6ef43bbd5113d9e212ceebfb98dc09a0", null ]
];