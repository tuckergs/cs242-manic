var classcom_1_1manic_1_1game_1_1entities_1_1_entity =
[
    [ "Entity", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#ab638d9a8ac1cf3a2181a0bf023bfab71", null ],
    [ "create", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#afea8fb54038a0b063bcca4433e6355bd", null ],
    [ "dispose", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a5ea195dd00df3e5cc826049ab3685b42", null ],
    [ "getCoordinates", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#aa0c0a5e69f04e4609f10d06e2d889d2b", null ],
    [ "getSpriteBatch", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a478fc289c95cf19b916a49df01d3de9a", null ],
    [ "render", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a793abdcbaa6e9bc7c28940d009412a1f", null ],
    [ "setCoordinates", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a6b5ed2e942d3a16f64f153f7d77f38e5", null ],
    [ "toString", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a345acb67b9313c24223599a66801c92f", null ],
    [ "update", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a086ed5d4913798534a3a3ee6e496cd5e", null ],
    [ "anim", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a365175c57e057e5560fa52286e96ef82", null ],
    [ "batch", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#ad359208addcc01913f2e6081c42b3061", null ],
    [ "coordinates", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a80c84a7adca30d435811dfa0483e3d1b", null ],
    [ "is_animated", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a733dbe679ae916930926ae75e8fe02a0", null ]
];