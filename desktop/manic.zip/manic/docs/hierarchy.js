var hierarchy =
[
    [ "com.manic.game.BodyDestroyer", "classcom_1_1manic_1_1game_1_1_body_destroyer.html", null ],
    [ "com.manic.game.android.BuildConfig", "classcom_1_1manic_1_1game_1_1android_1_1_build_config.html", null ],
    [ "Cloneable", null, [
      [ "com.manic.game.moves.Move", "classcom_1_1manic_1_1game_1_1moves_1_1_move.html", null ],
      [ "com.manic.game.ObjectTimeline< T >", "classcom_1_1manic_1_1game_1_1_object_timeline.html", null ]
    ] ],
    [ "com.manic.game.moves.CodeSnippet", "interfacecom_1_1manic_1_1game_1_1moves_1_1_code_snippet.html", null ],
    [ "Delegate", null, [
      [ "com.manic.game.IOSLauncher", "classcom_1_1manic_1_1game_1_1_i_o_s_launcher.html", null ]
    ] ],
    [ "com.manic.game.desktop.DesktopLauncher", "classcom_1_1manic_1_1game_1_1desktop_1_1_desktop_launcher.html", null ],
    [ "com.manic.game.entities.Entity", "classcom_1_1manic_1_1game_1_1entities_1_1_entity.html", [
      [ "com.manic.game.entities.GameEntity", "classcom_1_1manic_1_1game_1_1entities_1_1_game_entity.html", [
        [ "com.manic.game.entities.HitboxEntity", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html", [
          [ "com.manic.game.entities.Character", "classcom_1_1manic_1_1game_1_1entities_1_1_character.html", null ]
        ] ]
      ] ]
    ] ],
    [ "Exception", null, [
      [ "com.manic.game.exceptions.InvalidXMLException", "classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html", null ]
    ] ],
    [ "com.manic.game.helper.FileStuff", "classcom_1_1manic_1_1game_1_1helper_1_1_file_stuff.html", null ],
    [ "com.manic.game.FixtureDestroyer", "classcom_1_1manic_1_1game_1_1_fixture_destroyer.html", null ],
    [ "com.manic.game.states.GameState", "classcom_1_1manic_1_1game_1_1states_1_1_game_state.html", [
      [ "com.manic.game.states.MainMenu", "classcom_1_1manic_1_1game_1_1states_1_1_main_menu.html", null ],
      [ "com.manic.game.states.Start", "classcom_1_1manic_1_1game_1_1states_1_1_start.html", null ],
      [ "com.manic.game.states.Victory", "classcom_1_1manic_1_1game_1_1states_1_1_victory.html", null ]
    ] ],
    [ "com.manic.game.states.GameStateManager", "classcom_1_1manic_1_1game_1_1states_1_1_game_state_manager.html", null ],
    [ "com.manic.game.moves.Hitbox", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html", null ],
    [ "com.manic.game.HitboxFixtureUserData", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html", null ],
    [ "com.manic.game.moves.HitboxGroup", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html", null ],
    [ "com.manic.game.moves.HitboxType", "enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type.html", null ],
    [ "com.manic.game.InputHandler", "classcom_1_1manic_1_1game_1_1_input_handler.html", null ],
    [ "com.manic.game.resource_management.Moves", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html", null ],
    [ "com.manic.game.ObjectTimeline< com.manic.game.moves.CodeSnippet >", "classcom_1_1manic_1_1game_1_1_object_timeline.html", null ],
    [ "com.manic.game.ObjectTimeline< TextureRegion >", "classcom_1_1manic_1_1game_1_1_object_timeline.html", null ],
    [ "com.manic.game.android.R", "classcom_1_1manic_1_1game_1_1android_1_1_r.html", null ],
    [ "com.manic.game.resource_management.ResourceManager", "classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager.html", [
      [ "com.manic.game.resource_management.AnimationResourceManager", "classcom_1_1manic_1_1game_1_1resource__management_1_1_animation_resource_manager.html", null ]
    ] ],
    [ "com.manic.game.Settings", "classcom_1_1manic_1_1game_1_1_settings.html", null ],
    [ "com.manic.game.states.GameStateManager.State", "enumcom_1_1manic_1_1game_1_1states_1_1_game_state_manager_1_1_state.html", null ],
    [ "com.manic.game.xml.XMLParser", "classcom_1_1manic_1_1game_1_1xml_1_1_x_m_l_parser.html", [
      [ "com.manic.game.xml.AnimationDataParser", "classcom_1_1manic_1_1game_1_1xml_1_1_animation_data_parser.html", null ],
      [ "com.manic.game.xml.AnimationResourceManagerDataParser", "classcom_1_1manic_1_1game_1_1xml_1_1_animation_resource_manager_data_parser.html", null ]
    ] ],
    [ "AndroidApplication", null, [
      [ "com.manic.game.android.AndroidLauncher", "classcom_1_1manic_1_1game_1_1android_1_1_android_launcher.html", null ]
    ] ],
    [ "ApplicationListener", null, [
      [ "com.manic.game.Manic", "classcom_1_1manic_1_1game_1_1_manic.html", null ]
    ] ],
    [ "ContactListener", null, [
      [ "com.manic.game.MyContactListener", "classcom_1_1manic_1_1game_1_1_my_contact_listener.html", null ]
    ] ],
    [ "ControllerListener", null, [
      [ "com.manic.game.MyControllerListener", "classcom_1_1manic_1_1game_1_1_my_controller_listener.html", null ]
    ] ],
    [ "InputAdapter", null, [
      [ "com.manic.game.InputProcessor", "classcom_1_1manic_1_1game_1_1_input_processor.html", null ]
    ] ]
];