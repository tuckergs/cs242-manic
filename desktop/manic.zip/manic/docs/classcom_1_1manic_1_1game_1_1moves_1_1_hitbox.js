var classcom_1_1manic_1_1game_1_1moves_1_1_hitbox =
[
    [ "Hitbox", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a2ff49e37269f537c42905e59ac319731", null ],
    [ "destroy", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#aca0feaa3ff24ded675f63ed49a3f4f2a", null ],
    [ "getDamage", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#ae2819719ff1418e0ff40bbe65845b107", null ],
    [ "getHitboxID", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a3dc91c7683abd40226acf1e0d6023f9c", null ],
    [ "getHitstun", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a226c33a472e1b6020b2bed6e179af24e", null ],
    [ "getType", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a6d72169625a817ceacafda5c52a14205", null ],
    [ "is_destroyed", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a90d7037901426a6b133ad7710fbf52e9", null ],
    [ "damage", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a4d35bb41b0f3d5f5039bc412c7c5a244", null ],
    [ "hboxFixture", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a5285a6f45640a711f43a0812356afe12", null ],
    [ "hboxID", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#ac2e17bc7f450581a1ebf12e0c3fabf12", null ],
    [ "hitstun", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a5c358f6babd2f2541341a018face0f15", null ],
    [ "is_destroyed", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#aa309c6aecafa362bcb42b05be0da1180", null ],
    [ "type", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a2a2ebc0e3ff65bc4ad13c03ea97aad77", null ]
];