var searchData=
[
  ['victory',['Victory',['../classcom_1_1manic_1_1game_1_1states_1_1_victory.html',1,'com::manic::game::states']]]
];
