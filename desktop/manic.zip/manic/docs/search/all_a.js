var searchData=
[
  ['jump_5fforce_5fnewtons',['JUMP_FORCE_NEWTONS',['../classcom_1_1manic_1_1game_1_1states_1_1_start.html#aaca05d46a8355a3daffa68349b6485b8',1,'com::manic::game::states::Start']]]
];
