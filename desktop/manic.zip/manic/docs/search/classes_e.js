var searchData=
[
  ['xmlparser',['XMLParser',['../classcom_1_1manic_1_1game_1_1xml_1_1_x_m_l_parser.html',1,'com::manic::game::xml']]]
];
