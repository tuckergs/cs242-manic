var searchData=
[
  ['incrementhitstun',['incrementHitstun',['../classcom_1_1manic_1_1game_1_1entities_1_1_character.html#a47d7b84677e415f1df1e84fa8cc1b84a',1,'com::manic::game::entities::Character']]],
  ['init',['init',['../classcom_1_1manic_1_1game_1_1_object_timeline.html#a8575e73a322a455cede977c8e4fd3f5f',1,'com::manic::game::ObjectTimeline']]],
  ['inputhandler',['InputHandler',['../classcom_1_1manic_1_1game_1_1_input_handler.html',1,'com::manic::game']]],
  ['inputhandler_2ejava',['InputHandler.java',['../_input_handler_8java.html',1,'']]],
  ['inputprocessor',['InputProcessor',['../classcom_1_1manic_1_1game_1_1_input_processor.html',1,'com::manic::game']]],
  ['inputprocessor_2ejava',['InputProcessor.java',['../_input_processor_8java.html',1,'']]],
  ['invalid_5ftag',['INVALID_TAG',['../classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#aad6367d58e0147c169e7e51d95389ba0',1,'com::manic::game::exceptions::InvalidXMLException']]],
  ['invalidxmlexception',['InvalidXMLException',['../classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html',1,'com::manic::game::exceptions']]],
  ['invalidxmlexception',['InvalidXMLException',['../classcom_1_1manic_1_1game_1_1exceptions_1_1_invalid_x_m_l_exception.html#ac5bbedbda05895d71cb72b6c4c485035',1,'com::manic::game::exceptions::InvalidXMLException']]],
  ['invalidxmlexception_2ejava',['InvalidXMLException.java',['../_invalid_x_m_l_exception_8java.html',1,'']]],
  ['ioslauncher',['IOSLauncher',['../classcom_1_1manic_1_1game_1_1_i_o_s_launcher.html',1,'com::manic::game']]],
  ['ioslauncher_2ejava',['IOSLauncher.java',['../_i_o_s_launcher_8java.html',1,'']]],
  ['is_5fanimated',['is_animated',['../classcom_1_1manic_1_1game_1_1entities_1_1_entity.html#a733dbe679ae916930926ae75e8fe02a0',1,'com::manic::game::entities::Entity']]],
  ['is_5fdestroyed',['is_destroyed',['../classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#aa309c6aecafa362bcb42b05be0da1180',1,'com.manic.game.moves.Hitbox.is_destroyed()'],['../classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html#a90d7037901426a6b133ad7710fbf52e9',1,'com.manic.game.moves.Hitbox.is_destroyed()']]],
  ['is_5fflipped',['is_flipped',['../classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#abc75a7c608b47ef877ad38206de7331e',1,'com.manic.game.entities.HitboxEntity.is_flipped()'],['../classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a4baa442d45d8f27b7facf98eac93d6e7',1,'com.manic.game.entities.HitboxEntity.is_flipped()']]],
  ['is_5fget_5fon_5fno_5fkeyframe',['is_get_on_no_keyframe',['../classcom_1_1manic_1_1game_1_1xml_1_1_animation_data_parser.html#a625f9400b99b7b32a5eef5bdce2b0b27',1,'com::manic::game::xml::AnimationDataParser']]],
  ['is_5flooping',['is_looping',['../classcom_1_1manic_1_1game_1_1_object_timeline.html#a7e26a0431d30c129f60df8d7ad98df67',1,'com.manic.game.ObjectTimeline.is_looping()'],['../classcom_1_1manic_1_1game_1_1xml_1_1_animation_data_parser.html#acf8f01c1454da9e5c5d3d2940446288a',1,'com.manic.game.xml.AnimationDataParser.is_looping()']]],
  ['isdown',['isDown',['../classcom_1_1manic_1_1game_1_1_input_handler.html#ad60cbb0df927492e60217f55a78de79a',1,'com.manic.game.InputHandler.isDown()'],['../classcom_1_1manic_1_1game_1_1_input_handler.html#a83c3424fdf6b1bc3ed490ae8b38b6c42',1,'com.manic.game.InputHandler.isDown(int i)']]],
  ['isonground',['isOnGround',['../classcom_1_1manic_1_1game_1_1entities_1_1_character.html#a6a3de3db9f5f8e4fe1fe53a94fb597c1',1,'com.manic.game.entities.Character.isOnGround()'],['../classcom_1_1manic_1_1game_1_1_my_contact_listener.html#ab8ab5dd1c207d492933ff47bf1cbbde4',1,'com.manic.game.MyContactListener.isOnGround()'],['../classcom_1_1manic_1_1game_1_1entities_1_1_character.html#a04c6b41ee9d722dff209500ca6ee03d7',1,'com.manic.game.entities.Character.isOnGround()'],['../classcom_1_1manic_1_1game_1_1_my_contact_listener.html#a335aed5337ee04f4b60da53fce3edc95',1,'com.manic.game.MyContactListener.isOnGround()']]],
  ['ispressed',['isPressed',['../classcom_1_1manic_1_1game_1_1_input_handler.html#a67a9e7396a8183aa02ccd351bdaf3eff',1,'com.manic.game.InputHandler.isPressed()'],['../classcom_1_1manic_1_1game_1_1_input_handler.html#a56d199b73d846ff5129ed3f9a9732e4e',1,'com.manic.game.InputHandler.isPressed(int i)']]],
  ['isreleased',['isReleased',['../classcom_1_1manic_1_1game_1_1_input_handler.html#accf30e907703bb205337c9d1bcba4940',1,'com::manic::game::InputHandler']]]
];
