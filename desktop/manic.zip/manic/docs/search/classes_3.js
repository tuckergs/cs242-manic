var searchData=
[
  ['desktoplauncher',['DesktopLauncher',['../classcom_1_1manic_1_1game_1_1desktop_1_1_desktop_launcher.html',1,'com::manic::game::desktop']]]
];
