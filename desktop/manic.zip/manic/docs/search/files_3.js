var searchData=
[
  ['desktoplauncher_2ejava',['DesktopLauncher.java',['../_desktop_launcher_8java.html',1,'']]]
];
