var searchData=
[
  ['hitbox',['Hitbox',['../classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html',1,'com::manic::game::moves']]],
  ['hitboxentity',['HitboxEntity',['../classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html',1,'com::manic::game::entities']]],
  ['hitboxfixtureuserdata',['HitboxFixtureUserData',['../classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html',1,'com::manic::game']]],
  ['hitboxgroup',['HitboxGroup',['../classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html',1,'com::manic::game::moves']]],
  ['hitboxtype',['HitboxType',['../enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type.html',1,'com::manic::game::moves']]]
];
