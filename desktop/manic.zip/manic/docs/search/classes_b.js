var searchData=
[
  ['r',['R',['../classcom_1_1manic_1_1game_1_1android_1_1_r.html',1,'com::manic::game::android']]],
  ['resourcemanager',['ResourceManager',['../classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager.html',1,'com::manic::game::resource_management']]]
];
