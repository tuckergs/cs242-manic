var dir_537c53e5894bb5ea7f510ee520f24f77 =
[
    [ "AndroidLauncher.java", "_android_launcher_8java.html", [
      [ "AndroidLauncher", "classcom_1_1manic_1_1game_1_1android_1_1_android_launcher.html", "classcom_1_1manic_1_1game_1_1android_1_1_android_launcher" ]
    ] ]
];