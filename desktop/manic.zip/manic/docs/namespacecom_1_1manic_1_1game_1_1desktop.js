var namespacecom_1_1manic_1_1game_1_1desktop =
[
    [ "DesktopLauncher", "classcom_1_1manic_1_1game_1_1desktop_1_1_desktop_launcher.html", null ]
];