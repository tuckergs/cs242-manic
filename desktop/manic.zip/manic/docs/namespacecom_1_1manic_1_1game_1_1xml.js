var namespacecom_1_1manic_1_1game_1_1xml =
[
    [ "AnimationDataParser", "classcom_1_1manic_1_1game_1_1xml_1_1_animation_data_parser.html", "classcom_1_1manic_1_1game_1_1xml_1_1_animation_data_parser" ],
    [ "AnimationResourceManagerDataParser", "classcom_1_1manic_1_1game_1_1xml_1_1_animation_resource_manager_data_parser.html", "classcom_1_1manic_1_1game_1_1xml_1_1_animation_resource_manager_data_parser" ],
    [ "XMLParser", "classcom_1_1manic_1_1game_1_1xml_1_1_x_m_l_parser.html", "classcom_1_1manic_1_1game_1_1xml_1_1_x_m_l_parser" ]
];