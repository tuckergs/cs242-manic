var dir_47e9fcfb19af52fc19e9db0fede55fda =
[
    [ "DesktopLauncher.java", "_desktop_launcher_8java.html", [
      [ "DesktopLauncher", "classcom_1_1manic_1_1game_1_1desktop_1_1_desktop_launcher.html", null ]
    ] ]
];