var classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity =
[
    [ "HitboxEntity", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a00677be2424b7e0a52bda852da4ac0e7", null ],
    [ "addHitbox", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a6cbc3fe04ddc32ce873b388856f1b7ac", null ],
    [ "getFlipFactor", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a54539bfb77175fb1ba9f1b14ac0f5de5", null ],
    [ "getHitbox", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a8220b189c4f98b13dcb87bc72809cbdc", null ],
    [ "getHitboxes", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a009d2bf0d98431cce193522e7135d8c2", null ],
    [ "is_flipped", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a4baa442d45d8f27b7facf98eac93d6e7", null ],
    [ "putToEntityTable", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a700f84f19aace46d40cca5f57b754a23", null ],
    [ "removeAllHitboxes", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#aaa61e041fc27c5ae34cbb8fbd377ad84", null ],
    [ "removeHitbox", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#abd756106fda774c54229039a42cdfa6e", null ],
    [ "render", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#ad69cfc963dcab71827c2a2451a995e38", null ],
    [ "set_is_flipped", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a47b465c3a9a425b211456bdf86066ca9", null ],
    [ "hboxes", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#a47d724f20f6d5db71a9cdc58b69484ee", null ],
    [ "is_flipped", "classcom_1_1manic_1_1game_1_1entities_1_1_hitbox_entity.html#abc75a7c608b47ef877ad38206de7331e", null ]
];