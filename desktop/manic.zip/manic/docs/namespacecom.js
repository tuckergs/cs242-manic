var namespacecom =
[
    [ "manic", "namespacecom_1_1manic.html", "namespacecom_1_1manic" ]
];