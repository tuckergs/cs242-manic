var enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type =
[
    [ "CHARACTER", "enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type.html#ab9f16624c192ffbf61845733734cb18b", null ],
    [ "DAMAGING", "enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type.html#ae10bf90d2c20ee5facf39a0a233a4784", null ]
];