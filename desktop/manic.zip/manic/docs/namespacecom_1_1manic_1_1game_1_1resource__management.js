var namespacecom_1_1manic_1_1game_1_1resource__management =
[
    [ "AnimationResourceManager", "classcom_1_1manic_1_1game_1_1resource__management_1_1_animation_resource_manager.html", "classcom_1_1manic_1_1game_1_1resource__management_1_1_animation_resource_manager" ],
    [ "Moves", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves" ],
    [ "ResourceManager", "classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager.html", "classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager" ]
];