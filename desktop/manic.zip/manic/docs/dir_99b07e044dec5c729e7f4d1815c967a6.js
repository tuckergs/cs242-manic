var dir_99b07e044dec5c729e7f4d1815c967a6 =
[
    [ "FileStuff.java", "_file_stuff_8java.html", [
      [ "FileStuff", "classcom_1_1manic_1_1game_1_1helper_1_1_file_stuff.html", null ]
    ] ]
];