var classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data =
[
    [ "HitboxFixtureUserData", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#afab739fa843cc505b5f111a4183d8249", null ],
    [ "getEntity", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#a14a43d1b87f51d007a124f7f9e6c2c27", null ],
    [ "getEntityID", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#a701fa2c62563f9eb478b16a19b7fdaad", null ],
    [ "getHitbox", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#a677992bfcfc45e761fc7bf4052bc1aa8", null ],
    [ "getHitboxID", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#ae1dd2040d9d61554f60175ec9a1835e1", null ],
    [ "setEntityID", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#aabe3a018d1b37e5ec52112966353ffd6", null ],
    [ "setHboxID", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#a2501f548dc4714c27c3d00066f10e9e0", null ],
    [ "entityID", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#a0cd9202d00dc71940b0053568bbadf42", null ],
    [ "hboxID", "classcom_1_1manic_1_1game_1_1_hitbox_fixture_user_data.html#a13503212aa49b69a53e7412fdebde4d3", null ]
];