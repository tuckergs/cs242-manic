var classcom_1_1manic_1_1game_1_1_body_destroyer =
[
    [ "BodyDestroyer", "classcom_1_1manic_1_1game_1_1_body_destroyer.html#a9fb64c662a5e035406294bae8a42c0e2", null ],
    [ "add", "classcom_1_1manic_1_1game_1_1_body_destroyer.html#a6326918214ac7d5061c3c3f006d4c238", null ],
    [ "destroyAll", "classcom_1_1manic_1_1game_1_1_body_destroyer.html#a5dcdacd94d1b794fa3a180ffbf9dcdd8", null ]
];