var classcom_1_1manic_1_1game_1_1resource__management_1_1_moves =
[
    [ "Moves", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a855b235ed6bec02d236a875a6f9e33fe", null ],
    [ "createAnimationSagatStand", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a8dc7d434e8ef2bceaefb091d58504e62", null ],
    [ "createHitboxesSagatKick1", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#af24deb53be2c510c690a1dcb562c8e34", null ],
    [ "createHitboxesSagatKick2", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#ac814dcbc232136b40a013a456bc4b43a", null ],
    [ "createHitboxesSagatKick3", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a7c24dcae964071afb69f97eb3426f13e", null ],
    [ "createHitboxesSagatStand", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a753567840b60518450b31b48b97dcb40", null ],
    [ "createNothing", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a286595a8e15688d248e784d942e4ce11", null ],
    [ "createRenderLocationSagatStand", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a7b8a669e63a3803b3236c40ccd33ef58", null ],
    [ "createSagatAerial", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a96a0e85441a384749fe0a1078cce1e28", null ],
    [ "createSagatGroundKick", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#ad4d90656cd729390caca271906998d49", null ],
    [ "createSagatHitstun", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#ae5d6c2f4291c8a6131df486db4780238", null ],
    [ "createSagatStand", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a280068b1bc5da40dddd40b21140378e1", null ],
    [ "createTigerShotMove", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a80335fbe7c852fb29ee6cd87b2506650", null ],
    [ "get", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a7fe1f99427a952e2935d1e1aa8076a8b", null ],
    [ "load", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a4518c1e5860b6337bdfc512f79b8997e", null ],
    [ "playAttackSound", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a9ffb72ca408b346552e3142479856dd0", null ],
    [ "updateRenderLocationSagatKick", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a48a333edcab64bbd150e9c7471fe29d6", null ],
    [ "moves", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html#a894376e1ea0e4b40aff02287846a4e94", null ]
];