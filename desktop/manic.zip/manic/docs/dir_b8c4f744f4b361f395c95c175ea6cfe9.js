var dir_b8c4f744f4b361f395c95c175ea6cfe9 =
[
    [ "CodeSnippet.java", "_code_snippet_8java.html", [
      [ "CodeSnippet", "interfacecom_1_1manic_1_1game_1_1moves_1_1_code_snippet.html", "interfacecom_1_1manic_1_1game_1_1moves_1_1_code_snippet" ]
    ] ],
    [ "Hitbox.java", "_hitbox_8java.html", [
      [ "Hitbox", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox" ]
    ] ],
    [ "HitboxGroup.java", "_hitbox_group_8java.html", [
      [ "HitboxGroup", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group" ]
    ] ],
    [ "HitboxType.java", "_hitbox_type_8java.html", [
      [ "HitboxType", "enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type.html", "enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type" ]
    ] ],
    [ "Move.java", "_move_8java.html", [
      [ "Move", "classcom_1_1manic_1_1game_1_1moves_1_1_move.html", "classcom_1_1manic_1_1game_1_1moves_1_1_move" ]
    ] ]
];