var interfacecom_1_1manic_1_1game_1_1moves_1_1_code_snippet =
[
    [ "run", "interfacecom_1_1manic_1_1game_1_1moves_1_1_code_snippet.html#aefb0b719f37030fc0fa40f0de95eaf1e", null ]
];