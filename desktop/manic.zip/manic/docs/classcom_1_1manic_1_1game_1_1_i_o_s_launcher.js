var classcom_1_1manic_1_1game_1_1_i_o_s_launcher =
[
    [ "createApplication", "classcom_1_1manic_1_1game_1_1_i_o_s_launcher.html#a1d0009dda3bd0cd8efbe86b2bd77f7ec", null ]
];