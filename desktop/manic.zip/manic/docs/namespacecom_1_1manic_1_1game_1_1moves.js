var namespacecom_1_1manic_1_1game_1_1moves =
[
    [ "CodeSnippet", "interfacecom_1_1manic_1_1game_1_1moves_1_1_code_snippet.html", "interfacecom_1_1manic_1_1game_1_1moves_1_1_code_snippet" ],
    [ "Hitbox", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox.html", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox" ],
    [ "HitboxGroup", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group.html", "classcom_1_1manic_1_1game_1_1moves_1_1_hitbox_group" ],
    [ "HitboxType", "enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type.html", "enumcom_1_1manic_1_1game_1_1moves_1_1_hitbox_type" ],
    [ "Move", "classcom_1_1manic_1_1game_1_1moves_1_1_move.html", "classcom_1_1manic_1_1game_1_1moves_1_1_move" ]
];