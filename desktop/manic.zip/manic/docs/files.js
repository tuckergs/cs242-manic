var files =
[
    [ "android", "dir_c0734f77ea3dea2197fe756876cb58bd.html", "dir_c0734f77ea3dea2197fe756876cb58bd" ],
    [ "core", "dir_4270bfced15e0e73154b13468c7c9ad9.html", "dir_4270bfced15e0e73154b13468c7c9ad9" ],
    [ "desktop", "dir_634d989582191fdfe017f28ecbfd9152.html", "dir_634d989582191fdfe017f28ecbfd9152" ],
    [ "ios", "dir_a7bba106c16a515a6b03dd5c6c1257dd.html", "dir_a7bba106c16a515a6b03dd5c6c1257dd" ]
];