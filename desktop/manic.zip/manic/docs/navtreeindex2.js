var NAVTREEINDEX2 =
{
"namespacecom_1_1manic_1_1game_1_1entities.html":[2,0,0,0,0,2],
"namespacecom_1_1manic_1_1game_1_1exceptions.html":[1,0,0,0,0,3],
"namespacecom_1_1manic_1_1game_1_1exceptions.html":[2,0,0,0,0,3],
"namespacecom_1_1manic_1_1game_1_1helper.html":[2,0,0,0,0,4],
"namespacecom_1_1manic_1_1game_1_1helper.html":[1,0,0,0,0,4],
"namespacecom_1_1manic_1_1game_1_1moves.html":[2,0,0,0,0,5],
"namespacecom_1_1manic_1_1game_1_1moves.html":[1,0,0,0,0,5],
"namespacecom_1_1manic_1_1game_1_1resource__management.html":[2,0,0,0,0,6],
"namespacecom_1_1manic_1_1game_1_1resource__management.html":[1,0,0,0,0,6],
"namespacecom_1_1manic_1_1game_1_1states.html":[2,0,0,0,0,7],
"namespacecom_1_1manic_1_1game_1_1states.html":[1,0,0,0,0,7],
"namespacecom_1_1manic_1_1game_1_1xml.html":[2,0,0,0,0,8],
"namespacecom_1_1manic_1_1game_1_1xml.html":[1,0,0,0,0,8],
"namespaces.html":[1,0],
"pages.html":[]
};
