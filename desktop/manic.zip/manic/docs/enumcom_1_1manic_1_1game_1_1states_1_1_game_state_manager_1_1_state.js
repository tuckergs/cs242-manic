var enumcom_1_1manic_1_1game_1_1states_1_1_game_state_manager_1_1_state =
[
    [ "MAINMENU", "enumcom_1_1manic_1_1game_1_1states_1_1_game_state_manager_1_1_state.html#ac9a3f152e7bfd184cc025ad154264139", null ],
    [ "PLAY", "enumcom_1_1manic_1_1game_1_1states_1_1_game_state_manager_1_1_state.html#a35196102e7d123be846d2356df762ee8", null ],
    [ "RESTART", "enumcom_1_1manic_1_1game_1_1states_1_1_game_state_manager_1_1_state.html#ade21e28729dc0f34bfb21660b465ec1a", null ],
    [ "VICTORY", "enumcom_1_1manic_1_1game_1_1states_1_1_game_state_manager_1_1_state.html#a3a6f3f9b049513956683cd0fb47e0667", null ]
];