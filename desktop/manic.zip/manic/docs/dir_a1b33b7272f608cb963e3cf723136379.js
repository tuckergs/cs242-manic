var dir_a1b33b7272f608cb963e3cf723136379 =
[
    [ "AnimationResourceManager.java", "_animation_resource_manager_8java.html", [
      [ "AnimationResourceManager", "classcom_1_1manic_1_1game_1_1resource__management_1_1_animation_resource_manager.html", "classcom_1_1manic_1_1game_1_1resource__management_1_1_animation_resource_manager" ]
    ] ],
    [ "Moves.java", "_moves_8java.html", [
      [ "Moves", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves.html", "classcom_1_1manic_1_1game_1_1resource__management_1_1_moves" ]
    ] ],
    [ "ResourceManager.java", "_resource_manager_8java.html", [
      [ "ResourceManager", "classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager.html", "classcom_1_1manic_1_1game_1_1resource__management_1_1_resource_manager" ]
    ] ]
];