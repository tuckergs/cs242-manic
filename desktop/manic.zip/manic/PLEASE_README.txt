Our runnable jar is in the desktop folder.
